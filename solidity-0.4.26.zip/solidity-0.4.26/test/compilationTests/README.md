This directory contains various Solidity contract source code files
that are compiled as part of the regular tests.

These contracts are externally contributed and their presence in this
repository does not make any statement about their quality or usefulness.
