Giveth milestone tracker, originally from

https://github.com/Giveth/milestonetracker/
