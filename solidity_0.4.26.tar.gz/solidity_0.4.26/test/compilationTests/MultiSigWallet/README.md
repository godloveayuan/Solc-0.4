MultiSigWallet contracts, originally from

https://github.com/ConsenSys/MultiSigWallet
